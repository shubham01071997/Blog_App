package com.BlogApplication.util;

public class passwordGenerator {
	public static void main(String[] args) {
		
	}
}
