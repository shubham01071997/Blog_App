package com.BlogApplication.security;

import org.springframework.stereotype.Component;

@Component
public class JetTokenHelper {
	
	

}
