package com.BlogApplication.security;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.BlogApplication.Entity.User;
import com.BlogApplication.Exception.ResourceNotFoundException;
import com.BlogApplication.Exception.ResourceNotFoundExceptionNew;
@Service
public class CustomUserDetailService {//implements UserDetailsService{
	
//	@Autowired
//	private com.BlogApplication.Repository.UserRepository UserRepository;
//
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		User user= UserRepository.findByEmail(username).orElseThrow(()-> new  ResourceNotFoundExceptionNew("User","email",username));
//		return user;
//	}

}
